package net.sorwelt.pharma.component;

import net.minecraft.class_10124;
import net.minecraft.class_10128;
import net.minecraft.class_10132;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_4174;

public class ModFoodComponents {
    public record PharmaFood(class_4174 food, class_10124 consumable) {}

    private record EffectChance(class_1293 effect, float chance) {}

    private static class_4174 baseFood() {
        return new class_4174.class_4175()
                .method_19238(0)
                .method_19237(0.0f)
                .method_19240()
                .method_19242();
    }

    private static class_10124 consumable(EffectChance... effects) {
        class_10124.class_10125 builder = class_10128.method_62858();
        for (EffectChance effect : effects) {
            builder.method_62854(new class_10132(effect.effect(), effect.chance()));
        }
        return builder.method_62851();
    }

    private static EffectChance effect(class_1293 effect, float chance) {
        return new EffectChance(effect, chance);
    }

    // anxiolytics
    public static final PharmaFood ALPRAZOLAM = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f),
                    effect(new class_1293(class_1294.field_5902, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood PHENAZEPAM = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f),
                    effect(new class_1293(class_1294.field_5902, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood CLONAZEPAM = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f),
                    effect(new class_1293(class_1294.field_5902, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood DIAZEPAM = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f),
                    effect(new class_1293(class_1294.field_5902, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood TOFISOPAM = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5922, 1000, 1), 0.5f)
            )
    );

    // antipsychotics
    public static final PharmaFood HALOPERIDOL = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5911, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood QUETIAPINE = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5911, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood RISPERIDONE = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5911, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood CLORPROMAZINE = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5911, 1000, 1), 0.5f)
            )
    );

    // analgesics
    public static final PharmaFood TRAMADOL = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5907, 1000, 1), 0.5f),
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood PROMEDOL = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5907, 1000, 1), 0.5f),
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood PALEXIA = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5907, 1000, 1), 0.5f),
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood TROPICAMIDE = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5907, 1000, 1), 0.5f),
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f)
            )
    );

    // antidepressants
    public static final PharmaFood AMITRIPTYLINE = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5907, 1000, 1), 0.5f),
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood MIRTAZAPINE = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5924, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood ZOLOFT = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5924, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood FLUOXETINE = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5924, 1000, 1), 0.5f)
            )
    );

    // antihistamines
    public static final PharmaFood DRAMINA = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5916, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood DIMEDROL = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5916, 1000, 1), 0.5f)
            )
    );
    public static final PharmaFood ATARAX = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5916, 1000, 1), 0.5f)
            )
    );

    // antiepileptics
    public static final PharmaFood GABAPENTIN = new PharmaFood(
            baseFood(),
            consumable(
                    effect(new class_1293(class_1294.field_5909, 1000, 1), 0.5f)
            )
    );
}
