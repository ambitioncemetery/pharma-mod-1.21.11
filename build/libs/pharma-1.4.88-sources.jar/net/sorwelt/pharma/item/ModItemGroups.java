package net.sorwelt.pharma.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.sorwelt.pharma.PharmaMod;

public class ModItemGroups {
    // 5 разных вкладок в креативе
    public static final class_1761 ANXIOLYTICS_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            class_2960.method_60655(PharmaMod.MOD_ID, "anxiolytics"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemgroup.pharma.anxiolytics"))
                    .method_47320(() -> new class_1799(ModItems.ALPRAZOLAM))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModItems.ALPRAZOLAM);
                        entries.method_45421(ModItems.PHENAZEPAM);
                        entries.method_45421(ModItems.CLONAZEPAM);
                        entries.method_45421(ModItems.DIAZEPAM);
                        entries.method_45421(ModItems.TOFISOPAM);
                    })
                    .method_47324()
    );

    public static final class_1761 ANTIPSYCHOTICS_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            class_2960.method_60655(PharmaMod.MOD_ID, "antipsychotics"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemgroup.pharma.antipsychotics"))
                    .method_47320(() -> new class_1799(ModItems.HALOPERIDOL))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModItems.HALOPERIDOL);
                        entries.method_45421(ModItems.QUETIAPINE);
                        entries.method_45421(ModItems.RISPERIDONE);
                        entries.method_45421(ModItems.CLORPROMAZINE);
                    })
                    .method_47324()
    );

    public static final class_1761 ANALGESICS_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            class_2960.method_60655(PharmaMod.MOD_ID, "analgesics"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemgroup.pharma.analgetics"))
                    .method_47320(() -> new class_1799(ModItems.TRAMADOL))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModItems.TRAMADOL);
                        entries.method_45421(ModItems.PROMEDOL);
                        entries.method_45421(ModItems.PALEXIA);
                        entries.method_45421(ModItems.TROPICAMIDE);
                    })
                    .method_47324()
    );

public static final class_1761 ANTIDEPRESSANTS_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            class_2960.method_60655(PharmaMod.MOD_ID, "antidepressants"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemgroup.pharma.antidepressants"))
                    .method_47320(() -> new class_1799(ModItems.AMITRIPTYLINE))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModItems.AMITRIPTYLINE);
                        entries.method_45421(ModItems.MIRTAZAPINE);
                        entries.method_45421(ModItems.ZOLOFT);
                        entries.method_45421(ModItems.FLUOXETINE);
                    })
                    .method_47324()
    );

    public static final class_1761 ANTIHISTAMINES_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            class_2960.method_60655(PharmaMod.MOD_ID, "antihistamines"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemgroup.pharma.antihistamines"))
                    .method_47320(() -> new class_1799(ModItems.DRAMINA))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModItems.DRAMINA);
                        entries.method_45421(ModItems.DIMEDROL);
                        entries.method_45421(ModItems.ATARAX);
                    })
                    .method_47324()
    );

    public static final class_1761 ANTIEPILEPTICS_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            class_2960.method_60655(PharmaMod.MOD_ID, "antiepileptics"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemgroup.pharma.antiepileptics"))
                    .method_47320(() -> new class_1799(ModItems.GABAPENTIN))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModItems.GABAPENTIN);
                    })
                    .method_47324()
    );

    public static void registerItemGroups() {
        PharmaMod.LOGGER.info("zakepaem recepti v " + PharmaMod.MOD_ID);
    }
}