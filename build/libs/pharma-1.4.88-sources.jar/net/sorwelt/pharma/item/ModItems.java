package net.sorwelt.pharma.item;

import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.sorwelt.pharma.PharmaMod;
import net.sorwelt.pharma.component.ModFoodComponents;
import net.sorwelt.pharma.component.ModFoodComponents.PharmaFood;

public class ModItems {
    // anxiolytics
    public static final class_1792 ALPRAZOLAM = registerItem("alprazolam", ModFoodComponents.ALPRAZOLAM);
    public static final class_1792 PHENAZEPAM = registerItem("phenazepam", ModFoodComponents.PHENAZEPAM);
    public static final class_1792 CLONAZEPAM = registerItem("clonazepam", ModFoodComponents.CLONAZEPAM);
    public static final class_1792 DIAZEPAM = registerItem("diazepam", ModFoodComponents.DIAZEPAM);
    public static final class_1792 TOFISOPAM = registerItem("tofisopam", ModFoodComponents.TOFISOPAM);

    // antipsychotics
    public static final class_1792 HALOPERIDOL = registerItem("haloperidol", ModFoodComponents.HALOPERIDOL);
    public static final class_1792 QUETIAPINE = registerItem("quetiapine", ModFoodComponents.QUETIAPINE);
    public static final class_1792 RISPERIDONE = registerItem("risperidone", ModFoodComponents.RISPERIDONE);
    public static final class_1792 CLORPROMAZINE = registerItem("clorpromazine", ModFoodComponents.CLORPROMAZINE);

    // analgesics
    public static final class_1792 TRAMADOL = registerItem("tramadol", ModFoodComponents.TRAMADOL);
    public static final class_1792 PROMEDOL = registerItem("promedol", ModFoodComponents.PROMEDOL);
    public static final class_1792 PALEXIA = registerItem("palexia", ModFoodComponents.PALEXIA);
    public static final class_1792 TROPICAMIDE = registerItem("tropicamide", ModFoodComponents.TROPICAMIDE);

    // antidepressants
    public static final class_1792 AMITRIPTYLINE = registerItem("amitriptyline", ModFoodComponents.AMITRIPTYLINE);
    public static final class_1792 MIRTAZAPINE = registerItem("mirtazapine", ModFoodComponents.MIRTAZAPINE);
    public static final class_1792 ZOLOFT = registerItem("zoloft", ModFoodComponents.ZOLOFT);
    public static final class_1792 FLUOXETINE = registerItem("fluoxetine", ModFoodComponents.FLUOXETINE);

    // antihistamines
    public static final class_1792 DRAMINA = registerItem("dramina", ModFoodComponents.DRAMINA);
    public static final class_1792 DIMEDROL = registerItem("dimedrol", ModFoodComponents.DIMEDROL);
    public static final class_1792 ATARAX = registerItem("atarax", ModFoodComponents.ATARAX);

    // antiepileptics
    public static final class_1792 GABAPENTIN = registerItem("gabapentin", ModFoodComponents.GABAPENTIN);

    private static class_1792 registerItem(String name, PharmaFood pharmaFood) {
        class_2960 id = class_2960.method_60655(PharmaMod.MOD_ID, name);
        class_1792.class_1793 settings = new class_1792.class_1793()
                .method_62833(pharmaFood.food(), pharmaFood.consumable())
                .method_63686(class_5321.method_29179(class_7923.field_41178.method_46765(), id));
        return class_2378.method_10230(class_7923.field_41178, id, new class_1792(settings));
    }

    public static void registerModItems() {
        PharmaMod.LOGGER.info("zakypaem tabletki v " + PharmaMod.MOD_ID);
    }
}